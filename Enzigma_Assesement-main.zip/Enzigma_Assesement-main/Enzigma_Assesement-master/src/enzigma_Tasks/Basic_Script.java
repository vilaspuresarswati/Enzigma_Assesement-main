package enzigma_Tasks;

import Utility.BaseClass;

public class Basic_Script extends BaseClass {
	public static void main(String[] args) throws InterruptedException {
		preCondition();
		Thread.sleep(2000);
		postCondition();
	}

}
