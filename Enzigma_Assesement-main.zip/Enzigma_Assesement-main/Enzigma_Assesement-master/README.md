# **Selenium Automation for NoKodr Platform**  

## **Navigate To URL**: https://app-staging.nokodr.com/  

## **Overview:**   This project automates the Signup, Login, and Forgot Password functionalities of the NoKodr platform using Selenium WebDriver with Java.
  
## **Features:**  
  
Automates form validation for Signup, Login, and Forgot Password pages.  

Handles both valid and invalid input scenarios.  

Verifies error and success messages for different cases.  

## **Technologies Used:**  

Java ,  

Selenium WebDriver.  

# **Project Structure**  

selenium-nokodr-automation/  
├── src/  
│ ├──utility /  
| ├──Basic  
| ├──enzigma_Task  
│ │ └── ├── BaseTest.java  
│ │ ├── SignupTest.java  
│ │ ├── LoginTest.java  
│ │ └── ForgotPasswordTest.java  
├── resources/  
├── screenshots/  
│ └── (screenshots saved during test runs)  
├── README.md  
└── .gitignore  
